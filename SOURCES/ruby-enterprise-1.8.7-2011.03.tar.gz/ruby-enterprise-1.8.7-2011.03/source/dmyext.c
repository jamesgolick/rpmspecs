void
Init_ext()
{
}
