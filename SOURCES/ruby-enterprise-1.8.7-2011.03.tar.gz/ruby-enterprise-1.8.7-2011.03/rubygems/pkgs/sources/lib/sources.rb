module Gem
  @sources = %w[http://gems.rubyforge.org]
end
